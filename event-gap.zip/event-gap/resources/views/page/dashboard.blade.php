@extends('layout.baseUser')

@section('embedcss')
<link rel="stylesheet" href="{{asset('css/dashboard.css')}}">
@endsection

@section('content')
<div class="container categories">
    <h2>Kategori Event</h2>
    <div class="grid">
            <?php
                $title =["Education", "Health","Sport", "Anusement", "Job Vacancy","Tourism" ];
            ?>
        @for ($j = 0; $j < 2; $j++)
            <div class="row m-4">
                @for ($i = 0; $i < 3; $i++)
                    <div class="col col-4">
                        @if ($j > 0)
                        <a href="{{ url('event/kategori/'.($i+4))}}">
                        @else
                        <a href="{{ url('event/kategori/'.($i+1))}}">
                        @endif
                                <div class="card card-category">
                                    <div class="card-body">
                                        @if ($j > 0)
                                            <img src="{{asset('images/icon/'.($i+3).'.png')}}" alt="icon" srcset="" class="img-fluid"
                                            style="width: 90%; margin-left: 5%;">
                                        @else
                                            <img src="{{asset('images/icon/'.$i.'.png')}}" alt="icon" srcset="" class="img-fluid"
                                            style="width: 90%; margin-left: 5%;">
                                        @endif
                                    </div>
                                    @if ($j > 0)
                                        <h3 class="card-text" style="text-align: center;">{{ $title[$i+3] }}</h3>
                                    @else
                                        <h3 class="card-text" style="text-align: center;">{{ $title[$i] }}</h3>
                                    @endif
                                </div>
                            </a>
                    </div>
                @endfor
            </div>
        @endfor
    </div>
</div>

<div class="container event">
    <h2>Event Terbaru</h2>
    <div class="grid">
        @foreach($event as $event)
            <div class="card" style="width: 18rem; display: inline-block">
                <img class="card-img-top" src="{{ asset('images/event/'.$event->gambar)}}" alt="Card image cap">
                <div class="card-body">
                    <h5 class="card-title">{{$event -> namaEvent}}</h5>
                    <p class="card-text">{{ \Illuminate\Support\Str::limit($event->deskripsi, 60, '...') }}</p>
                    <a href="{{ url('event/'.$event->id)}}" class="btn btn-primary">Lihat..</a>
                </div>
            </div>
            @endforeach
    </div>
</div>
@endsection
