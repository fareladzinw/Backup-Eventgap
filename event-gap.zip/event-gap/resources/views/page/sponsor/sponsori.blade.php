@extends('layout.baseUser')

@section('embedcss')
<link rel="stylesheet" href="{{asset('css/sponsori.css')}}">
@endsection

@section('content')
<div class="container">
    @foreach($event as $event)
    <div class="card m-2">
        <h4 class="card-title text-center">{{$event->namaEvent}}</h4>
        <img class="card-img-top img-fluid w-50" src="{{ asset('images/event/'.$event->gambar)}}" alt="" style="margin-left :25%">
        <div class="card-body">
        @if(!$event->proposal==null)
            <h4 class="card-title text-center">Persyaratan Proposal</h4>
            <form action="{{route('downloadProposal',$event->id)}}" method="post">
                          {{csrf_field()}}
                          <div class="col-md-6"><button type="submit" class="btn btn-block btn-primary">download Proposal</button></div>
            </form>
            @else
            <h4 class="card-title text-center">Event ini tidak mengupload proposalnya</h4>
            @endif
        </div>
        <div class="card-footer">
            <a href="https://wa.me/+62{{$event->hp}}" class="btn btn-warning">Konfirmasi langsung ke EO </a>
        </div>
    </div>
    @endforeach
</div>
</div>
@endsection
