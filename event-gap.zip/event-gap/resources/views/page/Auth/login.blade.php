
@extends('layout.base')
@section('content')
<div class="registration-form">
    <form action="{{ route('checkLogin') }}" method="POST"> 
    {{ csrf_field() }}
    {{ method_field('POST') }}
        <b><h4>LOGIN</h4></b>
        <div class="form-icon">
            <img src="{{ asset('images/logo.png')}}" alt="" class="img-fluid">
        </div>
        <div class="form-group">
            <input type="text" class="form-control item" id="username" placeholder="Username" name="username">
        </div>
        <div class="form-group">
            <input type="password" class="form-control item" id="password" placeholder="Password" name="password">
        </div>
        <div class="form-group">
            <button type="submit" class="btn btn-block create-account">Login</button>
        </div>
    </form>
</div>
@endsection

@section('embedjs')
<script type="text/javascript" src="https://code.jquery.com/jquery-3.2.1.min.js"></script>
<script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/jquery.mask/1.14.15/jquery.mask.min.js">
</script>
@endsection

@section('embedcss')
<link href="https://cdnjs.cloudflare.com/ajax/libs/simple-line-icons/2.4.1/css/simple-line-icons.min.css"
    rel="stylesheet">
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css">
@endsection
