@extends('layout.baseUser')

@section('embedcss')
<link rel="stylesheet" href="{{asset('css/profile.css')}}">
@endsection

@section('content')
<div class="container">
    @if ($message = Session::get('alert-success'))
        <div class="alert alert-success m-2" role="alert">
            {{$message}}
        </div>
    @endif
    <div class="card" style="border:none;">
        <div class="card-header">
            @foreach($user as $user)
            <img class="card-img-top img-fluid w-50" src="{{!empty($user->gambar)  ? asset('images/foto-profil/'.$user->gambar) : asset('images/female-avatar.png')}}" alt=""
                style="margin-left :25%">
            <h5 class="text-center nama">{{$user->nama}}&emsp;<a href="#" data-toggle="modal"
                    data-target="#editProfile"><i class="fa fa-pencil-square-o" aria-hidden="true"></i></a></h5>
        </div>
        <div class="card-body">
            <p><i class="fa fa-address-book" aria-hidden="true"></i> {{!empty($user->domisili) ? $user->domisili:'-'}}
            </p>
            <p><i class="fa fa-facebook" aria-hidden="true"></i> {{!empty($user->facebook) ? $user->facebook:'-'}} </p>
            <p><i class="fa fa-twitter" aria-hidden="true"></i> {{!empty($user->twitter) ? $user->twitter:'-'}} </p>
            <p><i class="fa fa-instagram" aria-hidden="true"></i> {{!empty($user->instagram) ? $user->instagram:'-'}}
            </p>
            <p><i class="fa fa-phone" aria-hidden="true"></i> {{$user->hp}}</p>
            <p><i class="fa fa-envelope" aria-hidden="true"></i> {{$user->email}}</p>
            <br>
            @endforeach
            <div class="container event">
                @if (count($pembayaran) > 0)
                <h3>Pembelian Tiket</h3>
                <div class="card">
                    <div class="card-body">
                        <table class="table table-responsive table-hover">
                            <thead>
                                <tr>
                                    <th scope="col">Event</th>
                                    <th scope="col">Tiket</th>
                                    <th scope="col">Total</th>
                                    <th scope="col">Status</th>
                                    <th scope="col">Bukti Pembayaran</th>
                                    <th scope="col">Aksi</th>
                                </tr>
                                </thead>
                                <tbody>
                                    @foreach ($pembayaran as $k => $pembayaran)
                                        <tr>
                                            <td>{{$pembayaran->namaEvent}}</td>
                                            <td><a href = "#" data-toggle="modal" data-target="#pembayaran{{$k}}">Detail Tiket</a></td>
                                            <td>Rp.{{ number_format($pembayaran->total,2,',','.') }}</td>
                                            <td>
                                                @if ($pembayaran->status == 0)
                                                    Belum Dibayar
                                                @elseif($pembayaran->status == 1)
                                                    Menunggu Korfirmasi
                                                @else
                                                    Sudah Dibayar
                                                @endif
                                            </td>
                                            <td>
                                            <form action="{{ url("/upload-bukti/$pembayaran->id")}}" method="POST" enctype="multipart/form-data">
                                                    {{csrf_field()}}
                                                    <input type="file" name="buktiPembayaran">
                                            </td>
                                            <td>
                                                <button type="submit" class="btn btn-warning">Upload</button>
                                            </form>
                                            <form action="{{ route('batalPembayaran',$pembayaran->id)}}" method="POST" enctype="multipart/form-data">
                                                    {{csrf_field()}}
                                            <button class="btn btn-danger" type="submit">Batal pesan</button>
                                            </form>
                                            </td>
                                        </tr>
                                    @endforeach
                                </tbody>
                        </table>
                    </div>
                </div>
                @endif
                <h3>Event Saya</h3>
                <div class="grid m-">
                    @foreach($event as $event)
                    <div class="card m-2" style="width: 18rem; display: inline-block">
                        <img class="card-img-top" src="{{ asset('images/event/'.$event->gambar)}}" alt="Card image cap" class="w-50">
                        <div class="card-body">
                            <h5 class="card-title">{{$event ->namaEvent}}</h5>
                            <p class="card-text">{{ \Illuminate\Support\Str::limit($event->deskripsi, 60, '...') }}</p>
                            <a href="{{ url('event/'.$event->id)}}" class="btn btn-primary">Lihat..</a>
                        </div>
                    </div>
                    @endforeach
                </div>
            </div>
            <br>
        </div>
    </div>
</div>

<!-- Modal -->
<div class="modal fade" id="editProfile" tabindex="-1" role="dialog" aria-hidden="true">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="exampleModalLabel">Edit Profile</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body">
            <form action="{{ route('updateUser') }}" method="post" enctype="multipart/form-data">
            {{ csrf_field() }}
            {{ method_field('POST') }}
                    <div class="form-group">
                        <label for="">Nama</label>
                        <input type="text" class="form-control" name="nama" value="{{$user->nama}}">
                    </div>
                    <div class="form-group">
                        <label for="">Email</label>
                        <input type="text" class="form-control" name="email" value="{{$user->email}}">
                    </div>
                    <div class="form-group">
                        <label for="">Domisili</label>
                        <input type="text" class="form-control" name="domisili" value="{{$user->domisili}}">
                    </div>
                    <div class="form-group">
                        <label for="">Facebook</label>
                        <input type="text" class="form-control" name="facebook" value="{{$user->facebook}}">
                    </div>
                    <div class="form-group">
                        <label for="">Twitter</label>
                        <input type="text" class="form-control" name="twitter" value="{{$user->twitter}}">
                    </div>
                    <div class="form-group">
                        <label for="">Instagram</label>
                        <input type="text" class="form-control" name="instagram" value="{{$user->instagram}}">
                    </div>
                    <div class="form-group">
                        <label for="">No. HP</label>
                        <input type="text" class="form-control" name="hp" value="{{$user->hp}}">
                    </div>
                    <div class="form-group">
                        <label for="">Rekening</label>
                        <input type="text" class="form-control" name="rekening" value="{{$user->rekening}}" placeholder="ex. BCA - 123456789">
                    </div>
                    <div class="form-group">
                    <label for="">Foto</label>
                    <input type="file" class="form-control-file" id="" placeholder=""
                        aria-describedby="fileHelpId" name="gambar">
                </div>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                <button type="submit" class="btn btn-warning">Edit</button>
                </form>
            </div>
        </div>
    </div>
</div>
@endsection

@section('modal')
<!-- Modal -->
@foreach($detail as $k => $detail)
<div class="modal fade" id="pembayaran{{$k}}" tabindex="-1" role="dialog" aria-hidden="true">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="exampleModalLabel">Detail Tiket</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body">
                    <table class="table table-hover">
                <thead>
                  <tr>
                    <th scope="col">Nama Tiket</th>
                    <th scope="col">qty</th>
                    <th scope="col">harga</th>
                  </tr>
                </thead>
                <tbody>
                @foreach($detail as $d)
                    <tr>
                        <td>{{$d->namaTiket}}</td>
                        <td>{{$d->qty}}</td>
                        <td>Rp.{{ number_format($d->harga,2,',','.')}}</td>
                    </tr>
                @endforeach
                </tbody>
              </table>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
            </div>
        </div>
    </div>
</div>
@endforeach
@endsection
