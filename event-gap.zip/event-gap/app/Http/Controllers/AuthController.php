<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\User;
use App\Helper\Responses;
use Illuminate\Support\Facades\Auth;

class AuthController extends Controller
{
    public function indexLogin(){
        return view('page.Auth.login');
    }

    public function checkLogin(Request $request){
        $this->validate($request, [
            'username' => 'required',
            'password' => 'required',
        ]);

        $credentials = $request->only('username', 'password');

        if (Auth::attempt($credentials)) {
            return redirect('/dashboard');
        } else {
            return redirect('/login')->with('alert-fail','Email / password yang anda masukan salah!');
        }
    }
    
    public function indexRegister(){
        return view('page.Auth.register');
    }

    public function postRegister(Request $request){
        $this->validate($request,[
            'nama' => 'required',
            'username' => 'required',
            'email' => 'required|email',
            'password' => 'required',
            'hp' => 'required'
        ]);

        $data = new User();
        $data->nama = $request->nama;
        $data->username = $request->username;
        $data->email = $request->email;
        $data->password = bcrypt($request->password);
        $data->hp = $request->hp;
        $data->save();

        return redirect('/login')->with ('alert-success','Berhasil Membuat Akun !');
    }

    public function logout(){
        Auth::logout();
        return redirect('/')->with('alert-logout','Berhasil Logout!');
    }
}

