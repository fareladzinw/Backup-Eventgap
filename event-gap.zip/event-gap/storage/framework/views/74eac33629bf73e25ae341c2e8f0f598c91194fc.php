<?php $__env->startSection('embedcss'); ?>
<link rel="stylesheet" href="<?php echo e(asset('css/form.css')); ?>">
<style>
        @media (max-width : 425px){
            .card{
                overflow-x: scroll;
            }
        }
    </style>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="card bayar">
        <div class="card-body">
            <h2>Metode Pembayaran</h2>
            <h4 class="card-title">Transfer Rekening Penyelenggara Event</h4>
            <?php $__currentLoopData = $user; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <p><?php echo e($user->nama); ?></p>
            <p class="card-text"><?php echo e($user->rekening); ?></p>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </div>

    <div class="card beli">
        <div class="card-body">
            <h2>Pembelian Kamu</h2>
            <table class="table table-hover">
                <thead>
                    <tr>
                        <th>Tiketmu</th>
                        <th>Jumlah</th>
                        <th>Harga</th>
                    </tr>
                </thead>
                <?php $total = 0 ?>
                <tbody>
                <?php $__currentLoopData = $detail; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $detail): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($detail->namaTiket); ?></td>
                        <td><?php echo e($detail->qty); ?></td>
                        <td>Rp. <?php echo e($detail->harga); ?></td>
                    </tr>
                    <?php $total += $detail->harga ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <th colspan="2">Total pembayaran</th>
                        <th>Rp. <?php echo e($total); ?></th>
                    </tr>
                </tbody>
            </table>
            <form action="<?php echo e(url("/bayar-nanti/$pembayaran->id")); ?>" method="POST">
                <?php echo e(csrf_field()); ?>

                <?php echo e(method_field('POST')); ?>

            <button data-toggle="modal" data-target="#uploadBukti" class="btn btn-primary">Upload Bukti Pembayaran</button>
            <input type="hidden" name="total" value="<?php echo e($total); ?>">
            <button type="submit" class="btn btn-warning float-right">Bayar nanti</button>
            </form>

        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('modal'); ?>
<!-- Modal -->
<div class="modal fade" id="uploadBukti" tabindex="-1" role="dialog" aria-hidden="true">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="exampleModalLabel">Upload Bukti pembayaran</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body">
            <form action="<?php echo e(route('buyTiket',$pembayaran->id)); ?>" method="post" enctype="multipart/form-data">
            <?php echo e(csrf_field()); ?>

            <?php echo e(method_field('POST')); ?>

                    <div class="form-group">
                    <label for="">Bukti Pembayaran</label>
                    <input type="file" class="form-control-file" id="" placeholder=""
                        aria-describedby="fileHelpId" name="buktiPembayaran">
                    <input type="hidden" name="total" value = <?php echo e($total); ?>>
                </div>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                <button type="submit" class="btn btn-warning">Kirim</button>
                </form>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.baseUser', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\Proj.Laravel\event-gap\resources\views/page/beliTiket.blade.php ENDPATH**/ ?>