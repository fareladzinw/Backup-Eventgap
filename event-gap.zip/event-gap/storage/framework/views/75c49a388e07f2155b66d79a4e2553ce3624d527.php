<?php $__env->startSection('embedcss'); ?>
<link rel="stylesheet" href="<?php echo e(asset('css/dashboard.css')); ?>">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="container event">
        <?php $__currentLoopData = $kategori; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $kategori): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <h2> <?php echo e($kategori->namaKategori); ?> Event</h2>
        <div class="grid">
        <?php $__currentLoopData = $event; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $event): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="card" style="width: 18rem; display: inline-block">
                    <img class="card-img-top" src="<?php echo e(asset('images/event/'.$event->gambar)); ?>" alt="Card image cap">
                    <div class="card-body">
                        <h5 class="card-title"><?php echo e($event->namaEvent); ?></h5>
                        <p class="card-text"><?php echo e(\Illuminate\Support\Str::limit($event->deskripsi, 60, '...')); ?></p>
                        <a href="<?php echo e(url('event/'.$event->id)); ?>" class="btn btn-primary">Lihat..</a>
                    </div>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.baseUser', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\Proj.Laravel\event-gap\resources\views/page/sponsor/event.blade.php ENDPATH**/ ?>