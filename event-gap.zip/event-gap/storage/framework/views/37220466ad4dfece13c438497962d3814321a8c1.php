<?php $__env->startSection('embedcss'); ?>
<link rel="stylesheet" href="<?php echo e(asset('css/dashboard.css')); ?>">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="container categories">
    <h2>Kategori Event</h2>
    <div class="grid">
            <?php
                $title =["Education", "Health","Sport", "Anusement", "Job Vacancy","Tourism" ];
            ?>
        <?php for($j = 0; $j < 2; $j++): ?>
            <div class="row m-4">
                <?php for($i = 0; $i < 3; $i++): ?>
                    <div class="col col-4">
                        <?php if($j > 0): ?>
                        <a href="<?php echo e(url('event/kategori/'.($i+4))); ?>">
                        <?php else: ?>
                        <a href="<?php echo e(url('event/kategori/'.($i+1))); ?>">
                        <?php endif; ?>
                                <div class="card card-category">
                                    <div class="card-body">
                                        <?php if($j > 0): ?>
                                            <img src="<?php echo e(asset('images/icon/'.($i+3).'.png')); ?>" alt="icon" srcset="" class="img-fluid"
                                            style="width: 90%; margin-left: 5%;">
                                        <?php else: ?>
                                            <img src="<?php echo e(asset('images/icon/'.$i.'.png')); ?>" alt="icon" srcset="" class="img-fluid"
                                            style="width: 90%; margin-left: 5%;">
                                        <?php endif; ?>
                                    </div>
                                    <?php if($j > 0): ?>
                                        <h3 class="card-text" style="text-align: center;"><?php echo e($title[$i+3]); ?></h3>
                                    <?php else: ?>
                                        <h3 class="card-text" style="text-align: center;"><?php echo e($title[$i]); ?></h3>
                                    <?php endif; ?>
                                </div>
                            </a>
                    </div>
                <?php endfor; ?>
            </div>
        <?php endfor; ?>
    </div>
</div>

<div class="container event">
    <h2>Event Terbaru</h2>
    <div class="grid">
        <?php $__currentLoopData = $event; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $event): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="card" style="width: 18rem; display: inline-block">
                <img class="card-img-top" src="<?php echo e(asset('images/event/'.$event->gambar)); ?>" alt="Card image cap">
                <div class="card-body">
                    <h5 class="card-title"><?php echo e($event -> namaEvent); ?></h5>
                    <p class="card-text"><?php echo e(\Illuminate\Support\Str::limit($event->deskripsi, 60, '...')); ?></p>
                    <a href="<?php echo e(url('event/'.$event->id)); ?>" class="btn btn-primary">Lihat..</a>
                </div>
            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.baseUser', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\Proj.Laravel\event-gap\resources\views/page/dashboard.blade.php ENDPATH**/ ?>