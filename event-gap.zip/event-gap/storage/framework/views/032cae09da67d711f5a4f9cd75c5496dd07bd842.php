<?php $__env->startSection('embedcss'); ?>
 <style>
    .card{
        margin: 2rem;
        border: none;
        border-radius: 7px;
        box-shadow: 0 4px 8px 0 rgba(0,0,0,0.2);
        transition: 0.3s;
    }
 </style>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<!-- HERO -->
    <section class="hero hero-bg d-flex justify-content-center align-items-center">
        <div class="container">
                    <div class="row">

                        <div class="col-lg-6 col-md-10 col-12 d-flex flex-column justify-content-center align-items-center">
                            <div class="hero-text">

                                <h1 class="text-white" data-aos="fade-up">Kami siap membantu <strong>event</strong> anda</h1>

                                <a href="<?php echo e(url('/register')); ?>" class="custom-btn btn-bg btn mt-3" data-aos="fade-up" data-aos-delay="100">Buat Event !</a>
                            </div>
                        </div>

                        <div class="col-lg-6 col-12">
                        <div class="hero-image" data-aos="fade-up" data-aos-delay="300">

                            <img src="<?php echo e(asset('images/cele.png')); ?>" class="img-fluid" alt="working girl">
                        </div>
                        </div>

                    </div>
            </div>
    </section>


<!-- ABOUT -->
    <section class="about section-padding pb-0" id="about">
        <div class="container">
                <div class="row">

                    <div class="col-lg-7 mx-auto col-md-10 col-12">
                        <div class="about-info">

                            <h2 class="mb-4" data-aos="fade-up">Get your <strong>sponsorship</strong> !</h2>

                            <p class="mb-0" data-aos="fade-up">Lorem ipsum dolor, sit amet consectetur adipisicing elit. Quisquam, possimus? Facere reprehenderit non praesentium fuga, expedita quia impedit blanditiis doloremque provident totam cumque minus page.
                            <br><br>You are <strong>allowed</strong> to use this template for commercial or non-commercial purpose. You are NOT allowed to redistribute the template ZIP file on template collection websites.</p>
                        </div>

                        <div class="about-image" data-aos="fade-up" data-aos-delay="200">

                        <img src="images/office.png" class="img-fluid" alt="office">
                        </div>
                    </div>
                </div>
            </div>
    </section>



<!-- TESTIMONIAL -->
<section class="testimonial section-padding">
   <div class="container">
        <div class="row">

             <div class="col-lg-6 col-md-5 col-12">
                 <div class="contact-image" data-aos="fade-up">
                    <div class="card">
                        <img class="card-img-top" src="<?php echo e(asset('images/tab/0.jpg')); ?>" alt="" height="430px">
                        <div class="card-body">
                            <h4 class="card-title" style="text-align: center; color: black;">Sound System</h4>
                        </div>
                    </div>
                 </div>
             </div>

             <div class="col-lg-6 col-md-7 col-12" data-aos="fade-up">
                <div class="contact-image" data-aos="fade-up">
                    <div class="card">
                        <div class="bg" style="background-color : #75B9BC; border-top-right-radius: 7px; border-top-left-radius: 7px;">
                            <img class="card-img-top" src="<?php echo e(asset('images/tab/1.png')); ?>" alt="" height="430px">
                        </div>
                        <div class="card-body">
                            <h4 class="card-title" style="text-align: center; color: black;">Tent</h4>
                        </div>
                    </div>
                 </div>
             </div>

        </div>
   </div>
</section>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layout.base', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\Proj.Laravel\event-gap\resources\views/welcome.blade.php ENDPATH**/ ?>