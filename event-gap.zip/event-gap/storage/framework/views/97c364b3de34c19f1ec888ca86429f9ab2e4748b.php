<?php $__env->startSection('embedcss'); ?>
<link rel="stylesheet" href="<?php echo e(asset('css/profile.css')); ?>">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="container">
    <?php if($message = Session::get('alert-success')): ?>
        <div class="alert alert-success m-2" role="alert">
            <?php echo e($message); ?>

        </div>
    <?php endif; ?>
    <div class="card" style="border:none;">
        <div class="card-header">
            <?php $__currentLoopData = $user; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <img class="card-img-top img-fluid w-50" src="<?php echo e(!empty($user->gambar)  ? asset('images/foto-profil/'.$user->gambar) : asset('images/female-avatar.png')); ?>" alt=""
                style="margin-left :25%">
            <h5 class="text-center nama"><?php echo e($user->nama); ?>&emsp;<a href="#" data-toggle="modal"
                    data-target="#editProfile"><i class="fa fa-pencil-square-o" aria-hidden="true"></i></a></h5>
        </div>
        <div class="card-body">
            <p><i class="fa fa-address-book" aria-hidden="true"></i> <?php echo e(!empty($user->domisili) ? $user->domisili:'-'); ?>

            </p>
            <p><i class="fa fa-facebook" aria-hidden="true"></i> <?php echo e(!empty($user->facebook) ? $user->facebook:'-'); ?> </p>
            <p><i class="fa fa-twitter" aria-hidden="true"></i> <?php echo e(!empty($user->twitter) ? $user->twitter:'-'); ?> </p>
            <p><i class="fa fa-instagram" aria-hidden="true"></i> <?php echo e(!empty($user->instagram) ? $user->instagram:'-'); ?>

            </p>
            <p><i class="fa fa-phone" aria-hidden="true"></i> <?php echo e($user->hp); ?></p>
            <p><i class="fa fa-envelope" aria-hidden="true"></i> <?php echo e($user->email); ?></p>
            <br>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <div class="container event">
                <?php if(count($pembayaran) > 0): ?>
                <h3>Pembelian Tiket</h3>
                <div class="card">
                    <div class="card-body">
                        <table class="table table-responsive table-hover">
                            <thead>
                                <tr>
                                    <th scope="col">Event</th>
                                    <th scope="col">Tiket</th>
                                    <th scope="col">Total</th>
                                    <th scope="col">Status</th>
                                    <th scope="col">Bukti Pembayaran</th>
                                    <th scope="col">Aksi</th>
                                </tr>
                                </thead>
                                <tbody>
                                    <?php $__currentLoopData = $pembayaran; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $k => $pembayaran): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            <td><?php echo e($pembayaran->namaEvent); ?></td>
                                            <td><a href = "#" data-toggle="modal" data-target="#pembayaran<?php echo e($k); ?>">Detail Tiket</a></td>
                                            <td>Rp.<?php echo e(number_format($pembayaran->total,2,',','.')); ?></td>
                                            <td>
                                                <?php if($pembayaran->status == 0): ?>
                                                    Belum Dibayar
                                                <?php elseif($pembayaran->status == 1): ?>
                                                    Menunggu Korfirmasi
                                                <?php else: ?>
                                                    Sudah Dibayar
                                                <?php endif; ?>
                                            </td>
                                            <td>
                                            <form action="<?php echo e(url("/upload-bukti/$pembayaran->id")); ?>" method="POST" enctype="multipart/form-data">
                                                    <?php echo e(csrf_field()); ?>

                                                    <input type="file" name="buktiPembayaran">
                                            </td>
                                            <td>
                                                <button type="submit" class="btn btn-warning">Upload</button>
                                            </form>
                                            <button class="btn btn-danger">Batal pesan</button>
                                            </td>
                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                        </table>
                    </div>
                </div>
                <?php endif; ?>
                <h3>Event Saya</h3>
                <div class="grid m-">
                    <?php $__currentLoopData = $event; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $event): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="card m-2" style="width: 18rem; display: inline-block">
                        <img class="card-img-top" src="<?php echo e(asset('images/event/'.$event->gambar)); ?>" alt="Card image cap" class="w-50">
                        <div class="card-body">
                            <h5 class="card-title"><?php echo e($event ->namaEvent); ?></h5>
                            <p class="card-text"><?php echo e(\Illuminate\Support\Str::limit($event->deskripsi, 60, '...')); ?></p>
                            <a href="<?php echo e(url('event/'.$event->id)); ?>" class="btn btn-primary">Lihat..</a>
                        </div>
                    </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            </div>
            <br>
        </div>
    </div>
</div>

<!-- Modal -->
<div class="modal fade" id="editProfile" tabindex="-1" role="dialog" aria-hidden="true">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="exampleModalLabel">Edit Profile</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body">
            <form action="<?php echo e(route('updateUser')); ?>" method="post" enctype="multipart/form-data">
            <?php echo e(csrf_field()); ?>

            <?php echo e(method_field('POST')); ?>

                    <div class="form-group">
                        <label for="">Nama</label>
                        <input type="text" class="form-control" name="nama" value="<?php echo e($user->nama); ?>">
                    </div>
                    <div class="form-group">
                        <label for="">Email</label>
                        <input type="text" class="form-control" name="email" value="<?php echo e($user->email); ?>">
                    </div>
                    <div class="form-group">
                        <label for="">Domisili</label>
                        <input type="text" class="form-control" name="domisili" value="<?php echo e($user->domisili); ?>">
                    </div>
                    <div class="form-group">
                        <label for="">Facebook</label>
                        <input type="text" class="form-control" name="facebook" value="<?php echo e($user->facebook); ?>">
                    </div>
                    <div class="form-group">
                        <label for="">Twitter</label>
                        <input type="text" class="form-control" name="twitter" value="<?php echo e($user->twitter); ?>">
                    </div>
                    <div class="form-group">
                        <label for="">Instagram</label>
                        <input type="text" class="form-control" name="instagram" value="<?php echo e($user->instagram); ?>">
                    </div>
                    <div class="form-group">
                        <label for="">No. HP</label>
                        <input type="text" class="form-control" name="hp" value="<?php echo e($user->hp); ?>">
                    </div>
                    <div class="form-group">
                        <label for="">Rekening</label>
                        <input type="text" class="form-control" name="rekening" value="<?php echo e($user->rekening); ?>" placeholder="ex. BCA - 123456789">
                    </div>
                    <div class="form-group">
                    <label for="">Foto</label>
                    <input type="file" class="form-control-file" id="" placeholder=""
                        aria-describedby="fileHelpId" name="gambar">
                </div>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                <button type="submit" class="btn btn-warning">Edit</button>
                </form>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('modal'); ?>
<!-- Modal -->
<?php $__currentLoopData = $detail; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $k => $detail): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<div class="modal fade" id="pembayaran<?php echo e($k); ?>" tabindex="-1" role="dialog" aria-hidden="true">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="exampleModalLabel">Detail Tiket</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body">
                    <table class="table table-hover">
                <thead>
                  <tr>
                    <th scope="col">Nama Tiket</th>
                    <th scope="col">qty</th>
                    <th scope="col">harga</th>
                  </tr>
                </thead>
                <tbody>
                <?php $__currentLoopData = $detail; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $d): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($d->namaTiket); ?></td>
                        <td><?php echo e($d->qty); ?></td>
                        <td>Rp.<?php echo e(number_format($d->harga,2,',','.')); ?></td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
              </table>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
            </div>
        </div>
    </div>
</div>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.baseUser', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\Proj.Laravel\event-gap\resources\views/page/profile.blade.php ENDPATH**/ ?>