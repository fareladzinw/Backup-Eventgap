

<?php $__env->startSection('embedcss'); ?>
<link rel="stylesheet" href="<?php echo e(asset('css/sponsori.css')); ?>">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="container">
    <?php $__currentLoopData = $event; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $event): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <div class="card m-2">
        <h4 class="card-title text-center"><?php echo e($event->namaEvent); ?></h4>
        <img class="card-img-top img-fluid w-50" src="<?php echo e(asset('images/event/'.$event->gambar)); ?>" alt="" style="margin-left :25%">
        <div class="card-body">
        <?php if(!$event->proposal==null): ?>
            <h4 class="card-title text-center">Persyaratan Proposal</h4>
            <form action="<?php echo e(route('downloadProposal',$event->id)); ?>" method="post">
                          <?php echo e(csrf_field()); ?>

                          <div class="col-md-6"><button type="submit" class="btn btn-block btn-primary">download Proposal</button></div>
            </form>
            <?php else: ?>
            <h4 class="card-title text-center">Event ini tidak mengupload proposalnya</h4>
            <?php endif; ?>
        </div>
        <div class="card-footer">
            <a href="https://wa.me/+62<?php echo e($event->hp); ?>" class="btn btn-warning">Konfirmasi langsung ke EO </a>
        </div>
    </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.baseUser', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\Proj.Laravel\event-gap\resources\views/page/sponsor/sponsori.blade.php ENDPATH**/ ?>