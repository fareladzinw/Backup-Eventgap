

<?php $__env->startSection('embedcss'); ?>
<link rel="stylesheet" href="<?php echo e(asset('css/event.css')); ?>">
<?php echo $__env->yieldSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="container">
    <?php if($eventUserId == $userId): ?>
    <?php $__currentLoopData = $event; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $event): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <div class="title"><?php echo e($event->namaEvent); ?></div>

    <img src="<?php echo e(asset('images/event/'.$event->gambar)); ?>" alt="" srcset="" class="img-fluid banner"
        style="margin-left: 22%; border-radius: 5%;">
    <div class="title2">Event</div>

    <div class="desc">
         <p><i class="fa fa-map-marker" aria-hidden="true"></i> &emsp; <?php echo e($event->lokasi); ?></p>
         <?php if($event->dateTimeUntil == null): ?>
         <p><i class="fa fa-calendar" aria-hidden="true"></i> &emsp; <?php echo e(date('m-d-Y', strtotime($event->dateTimeFrom))); ?></p>
         <?php else: ?>
         <p><i class="fa fa-calendar" aria-hidden="true"></i> &emsp; <?php echo e(date('m-d-Y', strtotime($event->dateTimeFrom))); ?> - <?php echo e(date('m-d-Y', strtotime($event->dateTimeUntil))); ?></p>
         <?php endif; ?>
         <p><i class="fa fa-clock-o" aria-hidden="true"></i> &emsp; <?php echo e($event->waktu); ?></p>

    </div>
    <p style="word-break: break-all;">
    <?php echo e($event->deskripsi); ?>

    </p>
    <div class="title2">Diselenggarakan Oleh</div>
    <p><i class="fa fa-user" aria-hidden="true"></i>&emsp; <?php echo e($event->penyelenggara); ?></p>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    <?php if($isFree != 1): ?>
    <?php if(!$tiket->isEmpty()): ?>
    <div class="title2">Pembelian Ticket</div>
    <div class="ticket">
        <div class="container-fluid">
        <?php $__currentLoopData = $tiket; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tiket): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="row m-3">
                <div>
                        <div class="card">
                            <div class="row card-body">
                                <img class="col-sm-6" src="<?php echo e(asset('images/tiket/'.$tiket->gambar)); ?>" alt="sans"/>
                               <div class="col-sm-6">
                                    <div class="card-body">
                                            <h4 class="card-title"><?php echo e($tiket->namaTiket); ?></h4>
                                            <p class="card-text"><?php echo e($tiket->deskripsi); ?></p>
                                            <div class="row">
                                                <div class="col">
                                                <?php if($tiket->dateTimeUntil == null): ?>
                                                <p> <?php echo e(date('m-d-Y', strtotime($tiket->dateTimeFrom))); ?></p>
                                                <?php else: ?>
                                                <p> <?php echo e(date('m-d-Y', strtotime($tiket->dateTimeFrom))); ?> - <?php echo e(date('m-d-Y', strtotime($tiket->dateTimeUntil))); ?></p>
                                                <?php endif; ?>
                                                </div>
                                                <div class="col">
                                                    <p>Rp.<?php echo e($tiket->harga); ?></p>
                                                    <p class="card-text" style="color: red;"> Tiket tersisa <?php echo e($tiket->qty); ?></p>
                                                </div>
                                                <div class="col">
                                                    <a name="" id="" class="btn btn-event float-right btn-lg" href="<?php echo e(route('deleteTiket',$tiket->id)); ?>" role="button">Hapus Tiket</a>
                                                </div>
                                            </div>
                                        </div>
                                </div>
                            </div>
                        </div>
                </div>
        </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
    <?php else: ?>
    <div class="title2">Anda belum membuat tiket</div>
    </div>
    <?php endif; ?>
    <div class="container mb-2">
        <div class="row">
            <div class="col">
                <a name="" data-toggle="modal" data-target="#editProfile" class="btn btn-event btn-lg" href="#" role="button">Edit Event</a>
            </div>
            <div class="col">
                <a name="" id="" class="btn btn-event btn-lg" href="<?php echo e(url('/make-ticket/'.$event->id)); ?>" role="button">Buat Tiket</a>
            </div>
            <div class="col">
                <a name="" id="" class="btn btn-event btn-lg" href="<?php echo e(url('/table-acc/'.$event->id)); ?>" role="button">Pembeli Tiket</a>
            </div>
            <div class="col">
                <a name="" id="" class="btn btn-event btn-lg" href="<?php echo e(route('deleteEvent',$event->id)); ?>" role="button">Hapus Event</a>
            </div>
        </div>
    </div>
    <?php else: ?>
    <div class="btn-grub m-3">
        <div class="row">
            <div class="col">
                <a name="" data-toggle="modal" data-target="#editProfile" class="btn btn-event btn-lg float-right" href="#" role="button">Edit Event</a>
            </div>
            <div class="col"></div>
            <div class="col">
                <a name="" id="" class="btn btn-event btn-lg" href="<?php echo e(route('deleteEvent',$event->id)); ?>" role="button">Hapus Event</a>
            </div>
        </div>
    </div>
    <?php endif; ?>
</div>
    <?php elseif($eventUserId != $userId): ?>
    <?php $__currentLoopData = $event; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $event): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <div class="title"><?php echo e($event->namaEvent); ?></div>

    <img src="<?php echo e(asset('images/event/'.$event->gambar)); ?>" alt="" srcset="" class="img-fluid banner"
        style="margin-left: 22%; border-radius: 5%;">
    <div class="title2">Event</div>

    <div class="desc">
         <p><i class="fa fa-map-marker" aria-hidden="true"></i> &emsp; <?php echo e($event->lokasi); ?></p>
         <?php if($event->dateTimeUntil == null): ?>
         <p><i class="fa fa-calendar" aria-hidden="true"></i> &emsp; <?php echo e(date('m-d-Y', strtotime($event->dateTimeFrom))); ?></p>
         <?php else: ?>
         <p><i class="fa fa-calendar" aria-hidden="true"></i> &emsp; <?php echo e(date('m-d-Y', strtotime($event->dateTimeFrom))); ?> - <?php echo e(date('m-d-Y', strtotime($event->dateTimeUntil))); ?></p>
         <?php endif; ?>
         <p><i class="fa fa-clock-o" aria-hidden="true"></i> &emsp; <?php echo e($event->waktu); ?></p>

    </div>
    <p>
    <?php echo e($event->deskripsi); ?>

    </p>
    <div class="title2">Diselenggarakan Oleh</div>
    <p><i class="fa fa-user" aria-hidden="true"></i>&emsp; <?php echo e($event->penyelenggara); ?></p>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    <?php if($isFree != 1): ?>
    <?php if(!$tiket->isEmpty()): ?>
    <div class="title2">Pembelian Ticket</div>
    <div class="ticket">
        <div class="container-fluid">
        <form action="<?php echo e(route('buyPembayaran',$event->id)); ?>" method="post"enctype="multipart/form-data">
        <?php echo e(csrf_field()); ?>

        <?php echo e(method_field('POST')); ?>

        <?php $__currentLoopData = $tiket; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tiket): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="row m-3">
                <div>
                        <div class="card">

                            <div class="row card-body">
                                <img class="col-sm-6" src="<?php echo e(asset('images/tiket/'.$tiket->gambar)); ?>" alt="sans"/>
                                <input type="hidden" class="form-control" placeholder="" aria-describedby="helpId" name="tiketId[]" id="" value="<?php echo e($tiket->id); ?>">
                               <div class="col-sm-6">
                                    <div class="card-body">
                                            <h4 class="card-title"><?php echo e($tiket->namaTiket); ?></h4>
                                            <p class="card-text"><?php echo e($tiket->deskripsi); ?></p>
                                            <div class="row">
                                            <div class="col">
                                                <?php if($tiket->dateTimeUntil == null): ?>
                                                <p> <?php echo e(date('m-d-Y', strtotime($tiket->dateTimeFrom))); ?></p>
                                                <?php else: ?>
                                                <p> <?php echo e(date('m-d-Y', strtotime($tiket->dateTimeFrom))); ?> - <?php echo e(date('m-d-Y', strtotime($tiket->dateTimeUntil))); ?></p>
                                                <?php endif; ?>
                                                </div>
                                                <div class="col">
                                                    <p class="card-text" style="color: red;"> Tiket tersisa <?php echo e($tiket->qty); ?></p>
                                                </div>
                                                <div class="col">
                                                    <p>Rp.<?php echo e(number_format($tiket->harga,2,',','.')); ?></p>
                                                    <input type="hidden" class="form-control" placeholder="" aria-describedby="helpId" name="harga[]" id="" value="<?php echo e($tiket->harga); ?>">
                                                    <input type="number" class="form-control" placeholder="" aria-describedby="helpId" name="qty[]" id="" value="0">
                                                </div>
                                            </div>
                                        </div>
                                </div>
                            </div>
                        </div>
                </div>
        </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

    </div>
    <div class="btn-grub m-3">
        <div class="row">
            <div class="col">
                <a name="" id="" class="btn btn-event float-right btn-lg" href="<?php echo e(url('/sponsori/'.$event->id)); ?>" role="button">Sponsori</a>
            </div>
            <div class="col">
            <button type="submit" id="" class="btn btn-event btn-lg" role="button">Beli Tiket</button>
            </div>
            </form>
        </div>
    </div>
    <?php else: ?>
    <div class="title2">Event ini berbayar, tetapi belum terdapat Tiket</div>
    <div class="btn-grub m-3">
        <div class="row">
            <div class="col">
                <a name="" id="" class="btn btn-event float-right btn-lg" href="<?php echo e(url('/sponsori/'.$event->id)); ?>" role="button">Sponsori</a>
            </div>
            <div class="col"></div>
        </div>
    </div>
<?php endif; ?>
<?php else: ?>
<div class="title2">Event ini Gratis</div>
    <div class="btn-grub m-3">
        <div class="row">
            <div class="col">
                <a name="" id="" class="btn btn-event float-right btn-lg" href="<?php echo e(url('/sponsori/'.$event->id)); ?>" role="button">Sponsori</a>
            </div>
            <div class="col"></div>
        </div>
    </div>
<?php endif; ?>
</div>
<?php endif; ?>
</div>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('modal'); ?>
<!-- Modal -->
<div class="modal fade" id="editProfile" tabindex="-1" role="dialog" aria-hidden="true">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="exampleModalLabel">Edit Event</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body">
            <form action="<?php echo e(route('updateEvent',$event->id)); ?>" method="post"enctype="multipart/form-data">
            <?php echo e(csrf_field()); ?>

            <?php echo e(method_field('POST')); ?>

            <div class="form-group">
                    <label for="">Banner Event</label>
                    <input type="file" class="form-control-file" id="" placeholder=""
                        aria-describedby="fileHelpId" name="gambar" value="">
                </div>
                <div class="form-group">
                    <label for="">Nama Event</label>
                    <input type="text" id="" class="form-control" placeholder="" aria-describedby="helpId" name="namaEvent" value="<?php echo e($event->namaEvent); ?>">
                </div>
                <div class="form-group">
                    <label for="">Lokasi</label>
                    <input type="text" id="" class="form-control" placeholder="" aria-describedby="helpId" name="lokasi"value="<?php echo e($event->lokasi); ?>">
                </div>
                <div class="form-group">
                    <label for="">Tanggal Mulai</label>
                    <input type="date" class="form-control" value="<?php echo e($event->dateTimeFrom); ?>" name="dateTimeFrom"/>
                </div>
                <div class="form-group">
                    <label for="">Tanggal Berakhir</label>
                    <input type="date" class="form-control" value="<?php echo e($event->dateTimeUntil); ?>"  name="dateTimeUntil"/>
                </div>
                <div class="form-group">
                    <label for="">Waktu</label>
                    <input type="text" class="form-control" name="waktu" value="<?php echo e($event->waktu); ?>"/>
                </div>
                <div class="form-group">
                    <label for="">Deskripsi Event</label>
                    <textarea class="form-control" id="" rows="3" name="deskripsi" value="<?php echo e($event->deskripsi); ?>"></textarea>
                </div>
                <div class="form-group">
                    <label for="">Penyelenggara</label>
                    <input type="text" id="" class="form-control" placeholder="" aria-describedby="helpId" name="penyelenggara" value="<?php echo e($event->penyelenggara); ?>">

                </div>
                <div class="form-group">
                    <label for="">Contact Person</label>
                    <input type="text" id="" class="form-control" placeholder="Ex. @contactperson" aria-describedby="helpId" name="cp" value="<?php echo e($event->cp); ?>">
                <div class="form-group">
                    <label for=""><i class="fa fa-file-text" aria-hidden="true"></i> Proposal Event (PDF)</label>
                    <input type="file" class="form-control-file" name="proposal" id="" placeholder=""
                        aria-describedby="fileHelpId" value="">
                </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                <button type="submit" class="btn btn-warning">Edit</button>
                </form>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.baseUser', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\Proj.Laravel\event-gap\resources\views/page/sponsor/detailEvent.blade.php ENDPATH**/ ?>